<?php defined('BASEPATH') OR exit('No direct script access allowed');
class User_model extends CI_Model {

  public function verifyemail($kunci)
  {
    $data = array('status' => 1);
    $this->db->where('md5(Email)', $kunci);
    return $this->db->update('User', $data);
  }
  public function ubahpass()
  {
    $pass = $this->input->post('PasswordBaru');
		$ubah = $this->input->post('Email');
		$update = $this->db->query("UPDATE User SET Password = md5('$pass') WHERE Email = '$ubah' ");
    return $update;
  }
}

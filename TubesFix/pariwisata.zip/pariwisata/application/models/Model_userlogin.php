<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class model_userlogin extends CI_model {

	public function getlogin($u,$p)
	{
		$query = $this->db->get('User');
		$query = $this->db->get_where('User', array('Email'=>$u, 'password'=>md5($p)));
		return $query->row_array();
	}

	public function getlogin2($u,$p)
	{
		$pwd = md5($p);
		$this->db->where('Email',$u);
		$this->db->where('password',$pwd);
		$this->db->reconnect();
		$query = $this->db->get('User');
		if($query->num_rows()>0)
			{
				$res = $this->check_user($u, $pwd);
				if(!empty($res))
				{
					if($res[0]['status'] == '1')
					{
						foreach ($query->result() as $row)
						{
							$sess = array('Email' => $row->Email,
														'password' => $row->password );
							$this->session->set_userdata($sess);
							redirect('user');
						}
						$this->db->reconnect();
					}
					else
					{
						$this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Verifikasi Email Terlebih dahulu untuk login...</div>');
						redirect('user/login');
					}
					$this->db->reconnect();
				}
			}
			else
			{
				$this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Maaf Email atau Password salah...</div>');
				redirect('user/login');
				$this->db->reconnect();
			}
	}

	public function check_user($u,$pwd)
  {
    $sql = "SELECT status FROM User where Email = ? and Password = ?";
    $this->db->reconnect();
    $data = $this->db->query($sql, array($u,$pwd));
    return ($data->result_array()) ;
  }
}

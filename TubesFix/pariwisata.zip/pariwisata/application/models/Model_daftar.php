<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_daftar extends CI_model {

	public function getdata($key)
	{
		$this->db->where('Email',$key);
		$hasil = $this->db->get('User');
		return $hasil;
	}
	public function getinsert($data)
	{
		$this->db->where('Email');
		$this->db->insert('User',$data);
	}
	public function getdelete($key)
	{
		$this->db->where('Email',$key);
		$this->db->delete('User');
	}
	public function checkEmail($key) {
		if(!filter_var($key, FILTER_VALIDATE_EMAIL))
		{
         // invalid address
				 return false;
     }
     else
		 {
         // valid address
				 return true;
     }
	 }
	public function cekmail($key)
	 	{
			$this->db->where('Email',$key);
			$hasil = $this->db->get('User');
	 		if ($hasil->num_rows()>0) {
	 			# code...
				foreach ($hasil->result() as $row)
				{
					$sess = array('Email' => $row->Email);
					//$this->session->set_userdata($sess);
					return false;
				}
	 		}
			else {
				return true;
			}
	 	}
	}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_upload extends CI_model {
    function simpan_upload($gmbr)
    {
      $data = array(
          'gambar' => $gmbr
        );
          $result = $this->db->insert('tes',$data);
        return $result;
    }
}

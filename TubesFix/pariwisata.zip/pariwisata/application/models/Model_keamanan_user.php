<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_keamanan_user extends CI_model {

  public function getkeamananuser()
  {
    $Email = $this->session->userdata('Email');
    if(empty($Email))
    {
      $this->session->sess_destroy();
      redirect('beranda');
    }
  }
}

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Daftar Berhasil</title>
  </head>
  <body>
    <h1>Daftar Berhasil Silahkan Cek Email Untuk Verifikasi</h1>
  </body>
</html>

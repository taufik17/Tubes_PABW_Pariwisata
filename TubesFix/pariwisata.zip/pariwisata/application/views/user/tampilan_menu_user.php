<ul class="nav nav-list">
  <li class="active">
    <a href="<?php echo base_url();?>User">
      <i class="icon-home"></i>
      <span class="menu-text"> Dashboard </span>
    </a>
  </li>



  <li>
    <a href="<?php echo base_url();?>ObjekWisata" >
      <i class="icon-compass"></i>
      <span class="menu-text">Tambah Objek Wisata </span>
    </a>
  </li>




</ul><!--/.nav-list-->

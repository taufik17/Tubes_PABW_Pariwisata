<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Berhasil Di Verifikasi</title>
  </head>
  <body>
    <h1>Verifikasi Berhasil Login <a href="http://localhost/pariwisata/user/login">Disini</a>
    </h1>
  </body>
</html>

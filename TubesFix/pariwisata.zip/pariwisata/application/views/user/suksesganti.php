<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>sukses ganti password</title>

    <link rel="stylesheet" href="<?php echo base_url();?>ini/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?php echo base_url();?>ini/font-awesome/css/font-awesome.min.css">
    <!-- Google fonts - Roboto-->
    <link rel="stylesheet" href="<?php echo base_url();?>ini/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
  </head>
  <body>
    <div id="all">
      <!-- Top bar-->
      <div class="top-bar">
        <div class="container">
          <div class="row d-flex align-items-center">
            <div class="col-md-6 d-md-block d-none">
              <p>Contact us on +62 812 7813 1483 or info@comptech.id.</p>
            </div>
            <div class="col-md-6">
              <div class="d-flex justify-content-md-end justify-content-between">
                <ul class="list-inline contact-info d-block d-md-none">
                  <li class="list-inline-item"><a href="#"><i class="fa fa-phone"></i></a></li>
                  <li class="list-inline-item"><a href="#"><i class="fa fa-envelope"></i></a></li>
                </ul>
                <div class="login">
                  <a href="<?php echo base_url();?>" class="signup-btn"><i class="icon-home"></i><span class="d-none d-md-inline-block">BERANDA</span></a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Top bar end-->

      <section class="no-mb relative-positioned">
        <div style="background: url('<?php echo base_url('asset/images/bg-admin.jpg');?>') center center repeat; background-size: cover;" class="bar no-mb color-white text-center bg-fixed relative-positioned">
          <div class="dark-mask mask-primary"></div>
          <div class="container">
            <div class="row mb-small">
              <div class="col-md-12 text-center">
                <h2 class="text-uppercase">Password Berhasil Diperbarui</h2>
                <img class="col-md-4 text-center" src="<?php echo base_url();?>/img/log.png">
              </div>
            </div>
          </div>
          <a href="<?php echo base_url('login'); ?>" class="btn btn-lg btn-success"><i class="fa fa-sign-in"></i> Login</a>
        </div>
        <!-- *** JUMBOTRON END ***-->
      </section>
       <!-- FOOTER -->
       <div class="top-bar">
         <div class="container">
           <div class="row d-flex align-items-center">
             <div class="col-md-6 d-md-block d-none">
               <p>Comptech 2018</p>
             </div>
             <div class="col-md-6">
             </div>
           </div>
         </div>
       </div>
  </body>
</html>

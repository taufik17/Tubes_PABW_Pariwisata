<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Daftar extends CI_Controller {

	public function index()
	{
		$this->load->view('user/tampilan_daftar');
	}

	public function simpan()
	{
		$key = $this->input->post('Email');
		$email = $this->input->post('Email');
		$data['Email']		= $this->input->post('Email');
		$saltid   = md5($this->input->post('Email'));
		$status   = 0;
		$data['status']	= $status;
		$data['Email']			= $this->input->post('Email');
		$data['nama_member']			= $this->input->post('nama_member');
		$data['hengpon']		= $this->input->post('hengpon');
		$data['jenis_kelamin']	= $this->input->post('jenis_kelamin');
		$data['kota']	= $this->input->post('kota');
		$data['password']			= md5($this->input->post('password'));

		$this->load->model('model_daftar');
		$query = $this->model_daftar->getdata($key);
		$cek1=$this->model_daftar->checkEmail($key);
		$cek2=$this->model_daftar->cekmail($key);
		if($cek1 == false)
		{
			echo "<script>window.alert('Email anda invalid')</script>";
			echo "<meta http-equiv='refresh' content='0;url=https://pariwisata/daftar'>";

		}
			else
		{
			if ($cek2 == false) {
				echo "<script>window.alert('Email Sudah Terdaftar')</script>";
				echo "<meta http-equiv='refresh' content='0;url=http://localhost/pariwisata/daftar'>";
				# code...
			}
			else
			{
			$this->model_daftar->getinsert($data);
			$this->sendemail($email, $saltid);
			echo "<meta http-equiv='refresh' content='0;url=http://localhost/pariwisata/Berhasil_daftar/'>";
			}
		}
	}

	function sendemail($email,$saltid){
    // configure the email setting
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'ssl://smtp.gmail.com'; //smtp host name
    $config['smtp_port'] = '465'; //smtp port number
    $config['smtp_user'] = 'taufikagungsantoso17@gmail.com';
    $config['smtp_pass'] = 'InaSeptiana6++'; //$from_email password
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes
    $this->email->initialize($config);
    $url = base_url()."daftar/confirmation/".$saltid;
    $this->email->from('taufikagungsantoso17@gmail.com', 'VERIFIKASI PARIWISATA');
    $this->email->to($email);
    $this->email->subject('Verifikasi Email Pendaftaran');
    $message = "<html><head><head></head><body><p>Hi,</p><p>Terimakasih telah mendaftar.</p><p>ikuti tautan berikut untuk konfirmasi email.</p><a href=".$url."><b>VERIFIKASI</b></a><br/><p>Hormat,</p><p>Administrator Comptech</p></body></html>";
    $this->email->message($message);
    return $this->email->send();
  }

	public function confirmation($kunci)
  {
    if($this->user_model->verifyemail($kunci))
    {
      echo "<meta http-equiv='refresh' content='0;url=http://localhost/pariwisata/Berhasil_verifikasi/'>";
    }
    else
    {
      $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Email Gagal diverifikasi. Coba lagi nanti...</div>');
      redirect(base_url());
    }
  }
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lupapas extends CI_Controller {

	public function index()
	{
		$this->load->view('user/tampilan_lupasandi');
	}

	public function submit()
	{
    $key = $this->input->post('Email');
    $email = $this->input->post('Email');
    $saltid   = md5($this->input->post('Email'));
		$this->load->model('model_daftar');
		$query = $this->model_daftar->getdata($key);
		$cek1=$this->model_daftar->cekmail($key);
		if($cek1 == false)
		{
      $this->sendemail($email, $saltid);
      $this->session->set_flashdata('info', '<div class="alert alert-block alert-success">
          <button type="button" class="close" data-dismiss="alert">
          <i class="fa fa-remove"></i>
          </button>
          <i class="fa fa-ok green"></i>
          <strong class="green">
          </strong>Link Sudah Terkirim, Silahkan Cek Email Anda!!</div>');
          redirect('lupapas');
		}
			else
		{
      $this->session->set_flashdata('info', '<div class="alert alert-block alert-warning">
          <button type="button" class="close" data-dismiss="alert">
          <i class="fa fa-remove"></i>
          </button>
          <i class="fa fa-ok red"></i>
          <strong class="red">
          </strong>Maaf, Email Tidak Terdaftar</div>');
          redirect('lupapas');
		}
	}

	function sendemail($email,$saltid){
    // configure the email setting
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'ssl://smtp.gmail.com'; //smtp host name
    $config['smtp_port'] = '465'; //smtp port number
    $config['smtp_user'] = 'taufikagungsantoso17@gmail.com';
    $config['smtp_pass'] = 'InaSeptiana6++'; //$from_email password
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes
    $this->email->initialize($config);
    $url = base_url()."lupapas/gantipass/$email/".$saltid;
    $this->email->from('taufikagungsantoso17@gmail.com', 'Admin pariwisata');
    $this->email->to($email);
    $this->email->subject('PARIWISATA: Lupa Password');
    $message = "<html><head><head></head><body><p>Hi user pariwisata,</p><p>Kami beritahukan berikut adalah email pemberitahuan lupa password.</p><p>Silahkan ikuti tautan berikut untuk mengganti password lama Anda dengan password baru.</p><a href=".$url."><b>GANTI PASSWORD!</b></a><br/><p>Hormat Kami,</p><p>Administrator pariwisata</p></body></html>";
    $this->email->message($message);
    return $this->email->send();
  }

    public function gantipass($email)
    {
    $data['email'] = $email;
		$data['emailhash']   = $this->uri->segment('4');
    $this->load->view('user/tampilan_gantipas', $data);
    }

    function ganti_pass()
    {
			$emaildarireadonly = $this->input->post('Email');
	    $email_yang_di_hash   = $this->uri->segment('4');
			if (md5($emaildarireadonly) == $email_yang_di_hash) {
				$this->user_model->ubahpass();
				redirect('lupapas/suksesganti');
			}
			if (md5($emaildarireadonly) != $email_yang_di_hash) {
				redirect('lupapas/salahganti');
			}
  }

	function salahganti()
	{
		$this->load->view('user/salahganti');
	}

	function suksesganti(){
		$this->load->view('user/suksesganti');
	}
}
